# 钱庄一键存取发布记录

2026-09-30 已部署至 luanwu.top，项目目录 /root/code。

发布镜像：webgame:bank-bulk-20260930T113629Z
回滚备份：/root/code/releases/bank-bulk-20260930T113629Z/backup

仅包含七个运行时文件的钱庄改动，以发布前的线上镜像为基础，保留线上已有的返程护院分配规则。源文件与测试版本逐项校验一致。

数据库无需迁移。已收集静态资源并更新 Web、六个 Celery worker 和 Beat；Web health/ready、外网 health/live、新路由、模板渲染及公网静态脚本校验通过。六个 worker 均响应 ping，虚拟玩家已通过安全预检查并从本次 planned_restart 恢复至 v2_active。新容器日志未发现 ERROR 或异常栈。

验证：87 项回归、9 项真实 MySQL 并发、3 项浏览器测试通过；真实 MySQL 专项总计 27 项（含上述 9 项并发和 18 项服务测试）。

bank_bulk.patch 基于发布前线上源码生成；重用时需先核对 base_files 的 SHA-256，不能覆盖后续线上更新。

回滚：恢复备份的 .env.docker、七个 source 文件和 staticfiles，沿用 docker-compose.prod.yml 与 docker-compose.prod.double-caddy.yml 重建八个应用服务，再验证就绪与 worker 状态。旧镜像已保留。
